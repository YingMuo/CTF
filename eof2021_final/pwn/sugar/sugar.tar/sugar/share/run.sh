#!/bin/sh

exec 2>/dev/null
timeout 10 /home/sugar/sugar